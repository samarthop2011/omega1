const { spawnSync } = require('child_process');
const { collections, getNextId } = require('../lib/db');
const logger = require('../lib/logger');

function admin(user) { return !!(user && (user.role === 'admin' || user.root_admin)); }
function hasBin(bin) { const r = spawnSync('sh', ['-lc', `command -v ${bin}`], { encoding: 'utf8' }); return r.status === 0; }
function safeName(name) { const n = String(name || '').trim().replace(/\s+/g, '-'); if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{1,62}$/.test(n)) throw new Error('Invalid container hostname'); return n; }
function execLxc(args, opts={}) { const r = spawnSync('lxc', args, { encoding:'utf8', timeout: opts.timeout || 120000 }); if (r.status !== 0) throw new Error((r.stderr || r.stdout || 'LXC command failed').trim()); return (r.stdout || '').trim(); }

const OS = {
  ubuntu2204: { label:'Ubuntu 22.04', image:'images:ubuntu/22.04', user:'root' },
  ubuntu2404: { label:'Ubuntu 24.04', image:'images:ubuntu/24.04', user:'root' },
  debian12: { label:'Debian 12', image:'images:debian/12', user:'root' },
  debian13: { label:'Debian 13', image:'images:debian/13', user:'root' },
  alpine: { label:'Alpine Linux', image:'images:alpine/3.22', user:'root' },
  fedora: { label:'Fedora', image:'images:fedora/42', user:'root' },
};

async function list(ownerId=null) { const q=ownerId?{owner_id:Number(ownerId)}:{}; return collections.lxc_containers.find(q).sort({id:-1}).toArray(); }
async function get(id) { return collections.lxc_containers.findOne({id:Number(id)}); }
async function create({user,data}) {
  if (!admin(user)) throw new Error('Only administrators can deploy LXC containers until a plan/entitlement is assigned.');
  if (!hasBin('lxc')) throw new Error('LXC/Incus command `lxc` is not installed on this node.');
  const id=await getNextId('lxc_containers');
  const name=safeName(data.name || `vps-${id}`);
  const os=OS[data.os] || OS.ubuntu2404;
  const cpu=Math.max(1,Math.min(128,parseInt(data.cpus||2,10)));
  const ram=Math.max(128,Math.min(1048576,parseInt(data.memory||2048,10)));
  const disk=Math.max(1,Math.min(10000,parseInt(data.disk||20,10)));
  execLxc(['launch',os.image,name]);
  try {
    execLxc(['config','set',name,'limits.cpu',String(cpu)]);
    execLxc(['config','set',name,'limits.memory',`${ram}MB`]);
    execLxc(['config','device','override',name,'root','size',`${disk}GB`]);
  } catch(e) { try { execLxc(['delete','--force',name]); } catch(_){}; throw e; }
  const row={id,uuid:`lxc-${id}-${Date.now()}`,type:'lxc',owner_id:Number(data.owner_id||user.id),name,hostname:name,os:os.label,os_key:data.os||'ubuntu2404',image:os.image,cpus:cpu,memory:ram,disk_size:`${disk}G`,status:'running',node:'local',created_at:new Date().toISOString(),updated_at:new Date().toISOString()};
  await collections.lxc_containers.insertOne(row); return row;
}
async function power(c,action,user) { if (!admin(user) && Number(c.owner_id)!==Number(user.id)) throw new Error('Forbidden'); if(!hasBin('lxc')) throw new Error('lxc command unavailable'); const cmd=action==='start'?'start':action==='stop'?'stop':action==='restart'?'restart':null; if(!cmd) throw new Error('Unknown action'); execLxc([cmd,c.name]); await collections.lxc_containers.updateOne({id:Number(c.id)},{$set:{status:cmd==='stop'?'stopped':'running',updated_at:new Date().toISOString()}}); return get(c.id); }
async function remove(c,user){ if(!admin(user) && Number(c.owner_id)!==Number(user.id)) throw new Error('Forbidden'); if(hasBin('lxc')) { try{execLxc(['delete','--force',c.name]);}catch(e){logger.warn('[lxc] delete: '+e.message);} } await collections.lxc_containers.deleteOne({id:Number(c.id)}); return {ok:true}; }
function serialize(c){ if(!c)return null; return {...c}; }
module.exports={OS,list,get,create,power,remove,serialize,admin};
