# OmegaKVM Patch — LXC + Berserk Wallpapers

Changes in this build:
- Fixed the LXC admin page 500 error caused by `require is not defined` inside `views/admin/lxc.ejs`.
- The admin route now passes the LXC OS catalog to the EJS template as `osOptions`.
- Added a dedicated **Berserk** wallpaper category.
- Added a curated Berserk wallpaper fallback library so the chooser still has Berserk wallpapers when the external wallpaper provider is unavailable.
- Existing wallpaper upload, direct URL, favorites, preview, and apply flows are unchanged.
- Existing LXC backend behavior and resource handling are unchanged.

## Settings UI cleanup
- Removed customer-facing VM CPU and RAM edit controls from `views/user/server/settings.ejs`.
- Removed the VM disk resize control from the user VM Settings page.
- Existing server-side admin-only CPU/RAM update handling and disk-resize authorization remain intact.
- The Settings page continues to expose non-resource settings such as hostname, credentials, GUI mode, and port forwards.
